import React, { useState } from 'react';
import styled from "styled-components";
import TextField from '@material-ui/core/TextField';

import IconButton from '@material-ui/core/IconButton';
import RemoveIcon from '@material-ui/icons/Remove';
import AddIcon from '@material-ui/icons/Add';
import Icon from '@material-ui/core/Icon';
import { v4 as uuidv4 } from 'uuid';

import { makeStyles } from '@material-ui/core/styles';



const Container = styled.div`
//   width: 100vw;
//   height: 100vh;
//   background: linear-gradient(
//       rgba(255, 255, 255, 0.5),
//       rgba(255, 255, 255, 0.5)
//     ),
   
//       center;
//   background-size: cover;
//   display: flex;
//   align-items: center;

//   justify-content: center;
  
`;

const Wrapper = styled.div`
//   width: 40%;
//   padding: 20px;
//   height:500px;
//   justify-content: center;
//   background-color: white;
//   opacity:0.89;
//   border-radius: 20px;
 
  
 
`;

const Wrapper1 = styled.div`
//   margin-right:35px;
//   width: 40%;
//   padding: 20px;
//   height:500px;
//   justify-content: center;
//   background-color: white;
//   opacity:0.89;
//   border-radius: 20px;
 
  
 
`;

const Title = styled.h1`
//   font-size: 35px;
//   font-weight: 700;
//   align-items:center;
//   text-align:center;
//   color: #003580;
//   padding-top:30px;
//   padding-bottom:11px;
//   opacity:1;
  

`;

const Form = styled.form`
//   display: flex;
//   flex-wrap: wrap;
//   opacity:1;
`;

const Input = styled.input`
//   flex: 1;
//   font-weight:400;
//   font-size:20px;
//   min-width: 40%;
//   margin: 20px 10px 0px 0px;
//   padding: 15px;
//   opacity:1;
`;


const Button = styled.button`
//   width: 40%;
//   border: none;
//   padding: 15px 20px;
//   background-color: #003580;
//   color: white;
//   font-weight:bold;
//   font-size:20px;
//   cursor: pointer;
//   margin-top:60px;
//   margin-left:170px;
//   opacity:1;
`;

// const AddGuest = styled.h4`
//     color:#003580;
//     display:flex;
//     padding:20px;
    
// `;

// const Content = styled.div`
// width: 100vw;
// height: 100vh;
// // background: linear-gradient(
// //     rgba(255, 255, 255, 0.5),
// //     rgba(255, 255, 255, 0.5)
// //   ),
// //   url("")
// //     center;
// // background-size: cover;
// display: flex;
// align-items: center;
// // background-image: url("https://www.vobss.com/wp-content/uploads/2022/07/aesthetic-beach-wallpaper-vobss.jpg");
// justify-content: center;
// `;
// // const SearchItem = styled.div`
// // width: 25%;
// // padding: 20px;
// // background-color: white;
// // float:right;
// // `;

// const SiDesc = styled.div`
// color:#003580;
// align-items:center;
// `;
// const SiTitle = styled.h1`
//    font-weight:bolder;
//    color:#003580;
//    padding-top:11px;
//    padding-bottom:13px;
// `;
// const Desc = styled.span`
//  color:black;
//  font-weight:500;
//  font-size:20px;
//  float:left;
//  justify-content:space-between;
//  padding-bottom:11px;
 
// `;


function AddGuest() {
//   const classes = useStyles()
  const [inputFields, setInputFields] = useState([
    { id: uuidv4(), firstName: '', lastName: '',email:'',mobileNumber:'' },
  ]);

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("InputFields", inputFields);
  };

  const handleChangeInput = (id, event) => {
    const newInputFields = inputFields.map(i => {
      if(id === i.id) {
        i[event.target.name] = event.target.value
      }
      return i;
    })
    
    setInputFields(newInputFields);
  }

  const handleAddFields = () => {
    setInputFields([...inputFields, { id: uuidv4(),  firstName: '', lastName: '',email:'',mobileNumber:'' }])
  }

  const handleRemoveFields = id => {
    const values  = [...inputFields];
    values.splice(values.findIndex(value => value.id === id), 1);
    setInputFields(values);
  }

  return (
    <Container>
        <div>
        <b>Guest Details</b>
      <form onSubmit={handleSubmit}>
        { inputFields.map(inputField => (
          <div key={inputField.id}>
            {/* <TextField
              name="firstName"
              label="First Name"
              variant="filled"
              value={inputField.firstName}
              onChange={event => handleChangeInput(inputField.id, event)}
            />
            <TextField
              name="lastName"
              label="Last Name"
              variant="filled"
              value={inputField.lastName}
              onChange={event => handleChangeInput(inputField.id, event)}
            />

            <IconButton disabled={inputFields.length === 1} onClick={() => handleRemoveFields(inputField.id)}>
              <RemoveIcon />
            </IconButton>
            <IconButton
              onClick={handleAddFields}
            >
              <AddIcon />
            </IconButton> */}
           
          
            <Wrapper>
        
        
        <Input placeholder="Enter First name" type={"text"} 
        name="firstName"
              label="First Name"
              variant="filled"
              value={inputField.firstName}
              onChange={event => handleChangeInput(inputField.id, event)}
              required/>

        <Input placeholder="Enter Last name" type={"text"} 
        name="lastName"
        label="Last Name"
        variant="filled"
        value={inputField.lastName}
        onChange={event => handleChangeInput(inputField.id, event)}
        required/>

         <Input placeholder="Enter Email id" type={"email"}
         name="email"
         label="email"
         variant="filled"
         value={inputField.email}
         onChange={event => handleChangeInput(inputField.id, event)}
         required/>
        <Input placeholder="Enter Mobile number" type={"tel"} 
        name="mobileNumber"
        label="mobileNumber"
        variant="filled"
        value={inputField.mobileNumber}
        onChange={event => handleChangeInput(inputField.id, event)}
        required/> 
        
          {/* <AddGuest>+Add Guest</AddGuest><br/> */}
          <IconButton disabled={inputFields.length === 1} onClick={() => handleRemoveFields(inputField.id)}>
              RemoveGuest

              <RemoveIcon />
            </IconButton>

            <IconButton
              onClick={handleAddFields}
            >
                AddGuest
              <AddIcon />
            </IconButton>
           
       
        
         
      </Wrapper>
      </div>
     
        )) }
        {/* <Button
        //   className={classes.button}
          variant="contained" 
          color="primary" 
          type="submit" 
          endIcon={<Icon>send</Icon>}
          onClick={handleSubmit}
        >Add Guest</Button> */}
      </form>
       <Button>Pay Now</Button>



       </div>
    </Container>
  );
}

export default AddGuest;