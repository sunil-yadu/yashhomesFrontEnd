
import styled from "styled-components";

import React, { Component, useEffect, useReducer, useState } from 'react';

import Navbar from "../../components/navbar/Navbar";
import Footer from "../../components/footer/Footer";
import MailList from "../../components/mailList/MailList";
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faCodeFork} from '@fortawesome/free-solid-svg-icons';





const Container = styled.div`
  width: 100vw;
  height: 100vh;
  background: linear-gradient(
      rgba(255, 255, 255, 0.5),
      rgba(255, 255, 255, 0.5)
    ),
    url("https://images.pexels.com/photos/6984661/pexels-photo-6984661.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940")
      center;
  background-size: cover;
  display: flex;
  align-items: center;
  background-image: url("https://img.freepik.com/free-photo/maldives-island_74190-479.jpg?t=st=1657180375~exp=1657180975~hmac=44b40042230150b67abcae3f7e61a37e39d1b3f964915fd0bd0f53a94d9d2395&w=996");
  justify-content: center;
  
`;

const Wrapper = styled.div`
  width: 40%;
  padding: 20px;
  height:500px;
  justify-content: center;
  background-color: white;
  opacity:0.89;
  border-radius: 20px;
 
  
 
`;

const Wrapper1 = styled.div`
  margin-right:35px;
  width: 40%;
  padding: 20px;
  height:500px;
  justify-content: center;
  background-color: white;
  opacity:0.89;
  border-radius: 20px;
 
  
 
`;

const Title = styled.h1`
  font-size: 35px;
  font-weight: 700;
  align-items:center;
  text-align:center;
  color: #003580;
  padding-top:30px;
  padding-bottom:11px;
  opacity:1;
  

`;

const Form = styled.form`
  display: flex;
  flex-wrap: wrap;
  opacity:1;
`;

const Input = styled.input`
  flex: 1;
  font-weight:400;
  font-size:20px;
  min-width: 40%;
  margin: 20px 10px 0px 0px;
  padding: 15px;
  opacity:1;
`;


const Button = styled.button`
  width: 40%;
  border: none;
  padding: 15px 20px;
  background-color: #003580;
  color: white;
  font-weight:bold;
  font-size:20px;
  cursor: pointer;
  margin-top:60px;
  margin-left:170px;
  opacity:1;
`;

// const AddGuest = styled.h4`
//     color:#003580;
//     display:flex;
//     padding:20px;
    
// `;

// const Content = styled.div`
// width: 100vw;
// height: 100vh;
// // background: linear-gradient(
// //     rgba(255, 255, 255, 0.5),
// //     rgba(255, 255, 255, 0.5)
// //   ),
// //   url("")
// //     center;
// // background-size: cover;
// display: flex;
// align-items: center;
// // background-image: url("https://www.vobss.com/wp-content/uploads/2022/07/aesthetic-beach-wallpaper-vobss.jpg");
// justify-content: center;
// `;
// // const SearchItem = styled.div`
// // width: 25%;
// // padding: 20px;
// // background-color: white;
// // float:right;
// // `;

const SiDesc = styled.div`
color:#003580;
align-items:center;
`;
const SiTitle = styled.h1`
   font-weight:bolder;
   color:#003580;
   padding-top:11px;
   padding-bottom:13px;
`;
const Desc = styled.span`
 color:black;
 font-weight:500;
 font-size:20px;
 float:left;
 justify-content:space-between;
 padding-bottom:11px;
 
`;


const Register = () => {
  return (
    <>
    <Navbar />
    
    <Container>
      <Wrapper1>

       <SiDesc>
        <SiTitle><b>The Leela Mumbai </b>- Resort Style Business Hotel</SiTitle>
       
        <Desc>The Leela Mumbai is a 5 star luxury hotels in Mumbai near Mumbai international airport with a host of luxury amenities for leisure and business travelers.</Desc>
         <Desc>Near by Mumbai International Airport</Desc>
         <Desc>Free airport taxi</Desc><br />
         <Desc>
         Sophisticated hotel with stylish restaurants & bars, plus an outdoor pool & a high-end spa.
         </Desc>
         <Desc><b>Features :</b></Desc>
         <Desc>
           <b>5 star</b> | Top-rated | Great pool | Great location
         </Desc>
          <Desc>
           <b>Price Includes :</b> 
           <li> <FontAwesomeIcon icon="faCodeFork"/>Breakfast</li>
           <li>Advance Purchase</li>
           <Desc>
           </Desc>
         </Desc>
          
          </SiDesc>
         

       
  </Wrapper1>
  
  <Wrapper>
        <Title>GUEST DETAILS</Title>
        <Form>
        
        <Input placeholder="Enter First name" type={"text"} required/>
        <Input placeholder="Enter Last name" type={"text"} required/>
        <Input placeholder="Enter Email id" type={"email"} required/>
        <Input placeholder="Enter Mobile number" type={"tel"} required/> 
        
          {/* <AddGuest>+Add Guest</AddGuest><br/> */}
          <Button>Pay Now</Button>
       
        </Form>
         
      </Wrapper>

    </Container>
    <MailList />
    <Footer /></>
  );
};

export default Register;
