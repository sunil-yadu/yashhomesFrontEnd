import React from 'react'
import Navbar from '../../components/navbar/Navbar';
import MailList from "../../components/mailList/MailList";
import Footer from '../../components/footer/Footer';
//import Header from '../../components/header/Header';

const Bangalore = () => {
    return (
        <div>
            <Navbar />
            
      
    


    <div className="searchItem">
      <img
        src="https://lh3.googleusercontent.com/p/AF1QipPgIWRdCmLgUqrjt-88_Ec2VXXkJQmt_Xoa5iSf=w592-h404-n-k-rw-no-v1"
        alt=""
        className="siImg"
      />
       <div className="siDesc">
        <h1 className="siTitle">Holiday Inn Bengaluru Racecourse</h1>
        <span className="siDistance">Gandhi Nagar Bengaluru</span>
        <span className="siTaxiOp">Free airport taxi</span>
        <span className="siSubtitle">
        Cosy rooms in a functional lodging offering complimentary breakfast & Wi-Fi, plus a gym & a pool.
        </span>
        <span className="siFeatures">
          <b>5 star</b> | Breakfast | Free wifi | Outdoor pool
        </span>
        <span className="siCancelOp">Free cancellation </span>
        <span className="siCancelOpSubtitle">
          You can cancel later, so lock in this great price today!
        </span>
      </div>
      <div className="siDetails">
        <div className="siRating">
          <span>Outstanding</span>
          <button>9.5</button>
        </div>
        <div className="siDetailTexts">
          <span className="siPrice">Starts from Rs. 5348 per night </span>
          <span className="siTaxOp">Includes taxes and fees</span>
          <button className="siCheckButton">See availability</button>
        </div>
      </div>
    </div>


    <div className="searchItem">
      <img
        src="https://lh3.googleusercontent.com/p/AF1QipOfFsz8Lg-cy2jpKPv5fK-z5jCcDHnprmkZoBhR=w592-h404-n-k-rw-no-v1"
        alt=""
        className="siImg"
      />
      <div className="siDesc">
        <h1 className="siTitle">Lemon Tree Premier</h1>
        <span className="siDistance">Hermit Colony, Sivanchetti Gardens, Halasuru, Bangaluru</span>
        <span className="siTaxiOp">Free airport taxi</span>
        <span className="siSubtitle">
        Informal hotel offering warm rooms & suites, plus dining, a spa & a rooftop outdoor pool.
        </span>
        <span className="siFeatures">
          <b>4 star</b> |  Free Breakfast | Free wifi | Indoor pool
        </span>
        <span className="siCancelOp">Free cancellation </span>
        <span className="siCancelOpSubtitle">
          You can cancel later, so lock in this great price today!
        </span>
      </div>
      <div className="siDetails">
        <div className="siRating">
          <span>Excellent</span>
          <button>8.5</button>
        </div>
        <div className="siDetailTexts">
          <span className="siPrice">Starts from Rs. 4567 per night </span>
          <span className="siTaxOp">Includes taxes and fees</span>
          <button className="siCheckButton">See availability</button>
        </div>
      </div>
    </div>
    

            <MailList/>
            <Footer/>
        </div>
    );
};

export default Bangalore;












/*export default function Mumbai() {
  return (
    <><Navbar /><div>Mumbai</div><MailList /><Footer /></>
  )
}*/
