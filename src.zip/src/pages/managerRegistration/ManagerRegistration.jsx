import React from 'react'
import { useState } from "react";
import { Button } from "react-bootstrap";
import Col from "react-bootstrap/Col";
import Form from "react-bootstrap/Form";
import Row from "react-bootstrap/Row";


const ManagerRegister = () => {
    const [hotelName, setHotelName] = useState("");
    const [managerName, setManagerName] = useState("");
    const [mobileNumber, setMobileNumber] = useState("");
    const [emailId, setEmailId] = useState("");
    const [hotelRegistrationNumber, setHotelRegistrationNumber] = useState("");
    const [password, setPassword] = useState("");
    const [nameError, setNameError] = useState("");
    const [error, setError] = useState("");
    const [passwordError, setPasswordError] = useState("");
    const [isAgree, setIsAgree] = useState(false)
  
    const submitHandler = (e) => {
      e.preventDefault();
      console.log("submitted");
    };
  
    const validateName = (e) => {
      let namePattern = /^[A-Za-z]+$/;
  
      if (e.target.value === "" || namePattern.test(e.target.value)) {
        return setManagerName(e.target.value);
        // setNameError("");
      } else {
        console.log("please enter a valid name");
        setNameError("Please enter a valid name");
      }
    };
  
    const validateMobileNum = (e) => {
      let mobilePattern = /^\d+$/;
  
      if (e.target.value === "" || mobilePattern.test(e.target.value)) {
        setError("");
        return setMobileNumber(e.target.value);
      }
      console.log("please enter a no.");
      setError("please enter a number");
    };
  
    const validatePassword = (e) => {
      let passwordPattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,20}$/;
      setPassword(e.target.value);
      if (!passwordPattern.test(e.target.value)) {
        console.log("please enter strong password");
        setPasswordError("please enter strong password");
      } else {
        console.log("success");
  
        setPasswordError("");
      }
    };
    return (
      <div className="main">
        <div className="form-container">
          <h2 className="text-center m-3">REGISTER MANAGER</h2>
          <Form onSubmit={submitHandler}>
            <Row className="mb-3">
              <Col>
                <Form.Control
                  placeholder="Enter Hotel Name"
                  type={"text"}
                  value={hotelName}
                  onChange={(e) => {
                    setHotelName(e.target.value);
                  }}
                  required
                />
              </Col>
              <Col>
                <Form.Control
                  placeholder="Enter Manager Name"
                  type={"text"}
                  value={managerName}
                  onChange={validateName}
                  required
                />
                {nameError && <span className="text-danger">{nameError}</span>}
              </Col>
            </Row>
            <Row className="mb-3">
              <Col>
                <Form.Control
                  placeholder="Registration Number"
                  type={"text"}
                  value={hotelRegistrationNumber}
                  onChange={(e) => {
                    setHotelRegistrationNumber(e.target.value);
                  }}
                  required
                />
              </Col>
              <Col>
                <Form.Control
                  placeholder="Enter Mobile Number"
                  maxLength={10}
                  type={"tel"}
                  value={mobileNumber}
                  onChange={validateMobileNum}
                  required
                />
                {error && <span className="text-danger">{error}</span>}
              </Col>
            </Row>
            <Row className="mb-3">
              <Col>
                <Form.Control
                  placeholder="Enter email id"
                  type={"email"}
                  value={emailId}
                  onChange={(e) => {
                    setEmailId(e.target.value);
                  }}
                  required
                />
              </Col>
              <Col>
                <Form.Control
                  placeholder="password"
                  type={"password"}
                  value={password}
                  onChange={validatePassword}
                  required
                />
                {passwordError && (
                  <span className="text-danger">{passwordError}</span>
                )}
              </Col>
            </Row>
            <Row>
              <Form.Check 
                  type="checkbox"
                  checked={isAgree}
                  onClick={(e)=>{
                      setIsAgree(!isAgree)
                  }}
                  label={<h6>
                      By creating an account, I consent to the processing of my personal
                      <br />
                      data in accordance with the <b>PRIVACY POLICY</b>
                  </h6>}
              />    
            </Row>
            <div className="text-center">
            <Button
              disabled={error || nameError || passwordError || !isAgree}
              className="btn btn-primary btn-lg"
              style={{backgroundColor:"#003580"}}
            >
              REGISTER
            </Button>
            {/* <Button
              className="btn btn-secondary btn-lg"
            >
              LOGIN
            </Button> */}
            </div>
          </Form>
        </div>
      </div>
    );
  }

export default ManagerRegister