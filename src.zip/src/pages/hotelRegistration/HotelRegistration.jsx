import React from "react";
import { useState } from "react";
//import "./hotelRegistration.css"

const RegisterManager = () => {
    const [registrationNumber, setHotelRegistrationNumber] = useState("");

    const [hotelName, setHotelName] = useState("");
    const [totalRooms, setTotalRooms] = useState("");
    const [availableAcRooms, setAvailableAcRooms] = useState("");
    const [availableNonAcRooms, setAvailableNonAcRooms] = useState("");
    const [address, setAddress] = useState("");
    const [charges, setCharges] = useState("");
    const [foodIncluded, setFoodIncluded] = useState("");
    const [isBar, setIsBar] = useState("");

    const handleClick = (event) => {
      alert("check");
      event.preventDefault()
      const hotel = {registrationNumber,hotelName,totalRooms,availableAcRooms,availableNonAcRooms,address,charges,foodIncluded,isBar}
      console.log(hotel);
      fetch("http://localhost:8080/saveHotelInformation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(hotel)
  
      }).then(() => {
        console.log("New User added")
      })
  
    }
  
  
    // useEffect(() => {
    //   fetch("http://localhost:8080//getAll")
    //     .then(res => res.json())
    //     .then((result) => {
    //       setUserRagistration(result);
    //     }
    //     )
    // }, [])
  
    const submitHandler = (e) => {
      e.preventDefault()
      console.log("submitted");
    }


    // const [hotelOwnerName, setHotelOwnerName] = useState("");
    // const [contactNumber, setContactNumber] = useState("");
    // const [emailId, setEmailId] = useState("");
    
    // const [password, setPassword] = useState("");
    // const [error, setError] = useState("")
    // const [passwordError, setPasswordError] = useState("")

    // const [greeting, setGreeting] = useState("hello world")

//  const handleChange = (event)=>{
//     console.log(event.target.value);
//     setHotelName(event.target.value);

// }


// const submitHandler = (e)=>{
//     e.preventDefault()
//     console.log("submitted");
// }
//     // function handleChange(event){
//     //     console.log(event.target.value)           
//     // }


// const validateContactNum =(e)=>{
//     let contactPattern = /^\d+$/
    
//     if(e.target.value==="" || contactPattern.test(e.target.value) ){
//        return setContactNumber(e.target.value)
//        setError("");
//     }
//         console.log("enter a no.");
//         setError("please enter a number")

    

// }

// const validatePassword =  (e)=>{
//     let passwordPattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,20}$/;
// setPassword(e.target.value)
// if(!passwordPattern.test(e.target.value)){
//     console.log("please enter strong password");
//     setPasswordError("please enter strong password")
// }else{
//     console.log("success");
//     setPasswordError("")
// }
    
// }




  return (
    <div className="main">
        {/* <span style={{
            color: "red",
            backgroundColor:"GrayText"
        }} >{error}</span> */}
        <div className="main-header"><h2>Hotel Information Form</h2></div>
      <form
       onSubmit={submitHandler}
    >
      <div className="first">
          <label htmlFor="">Hotel Registration Number</label><br />
          <input type="text" value={registrationNumber} onChange={(e)=>{
            setHotelRegistrationNumber(e.target.value)
          }} placeholder="Enter hotel registration number" required/>
        </div>

        <div>
          <label htmlFor="">Hotel Name</label><br />
          <input type="text" value={hotelName} onChange={(event) => {
              setHotelName(event.target.value)
            }} placeholder="Enter hotel name" required/>
        </div>
        <div>
          <label htmlFor="">Total Rooms</label><br />
          <input type="text" value={totalRooms} onChange={(event) => {
              setTotalRooms(event.target.value)
            }} placeholder="Enter Total Rooms" required/>
        </div>
        <div>
          <label htmlFor="">Total Available Ac Rooms</label><br />
          <input type="text" value={availableAcRooms} onChange={(event) => {
              setAvailableAcRooms(event.target.value)
            }} placeholder="Enter Total Available Ac Rooms" required/>
        </div>
        <div>
          <label htmlFor="">Total Available NonAc Rooms</label><br />
          <input type="text" value={availableNonAcRooms} onChange={(event) => {
              setAvailableNonAcRooms(event.target.value)
            }} placeholder="Enter Total Available NonAc Rooms" required/>
        </div>
        <div>
          <label htmlFor="">Address</label><br />
          <input type="text" value={address} onChange={(event) => {
              setAddress(event.target.value)
            }} placeholder="Enter Your Address" required/>
        </div>
        <div>
          <label htmlFor="">Charges</label><br />
          <input type="text" value={charges} onChange={(event) => {
              setCharges(event.target.value)
            }} placeholder="Enter Charges" required/>
        </div>
        <div>
          <label htmlFor="">FoodIncluded</label><br />
          <input type="text" value={foodIncluded} onChange={(event) => {
              setFoodIncluded(event.target.value)
            }} placeholder="Enter Food Included or not" required/>
        </div>
        <div>
          <label htmlFor="">Bar Availability</label><br />
          <input type="text" value={isBar} onChange={(event) => {
              setIsBar(event.target.value)
            }} placeholder="Enter Bar Availabiliy" required/>
        </div>




{/*         
        <div>
          <label htmlFor="">Hotel Owner Name</label><br />
          <input type="text" value={hotelOwnerName} onChange={(e)=>{
           setHotelOwnerName(e.target.value)
          }} placeholder="Enter hotel owner name" required/>
        </div>
        
        <div>
          <label htmlFor="">Contact Number</label><br />
          <input type="tel" maxLength={10} value={contactNumber} onChange={validateContactNum} placeholder="Enter contact number" required/>
          <span style={{color:"red"}}>{error}</span>
        </div>
        
        <div>
          <label htmlFor="">Email ID</label><br />
          <input type="email" value={emailId} onChange={(e)=>{
            setEmailId(e.target.value)
          }} placeholder="Enter email id" required/>
        </div>
        
        
        
        <div>
          <label htmlFor="">Password</label><br />
          <input type="password" value={password} onChange={validatePassword} placeholder="Enter password"  required/>
          <span style={{
            color: "red"
        }} >{passwordError}</span>
        </div> */}

          <div className="submitBtn">
            {/* <button  type="submit">Submit</button> */}
            <input type="submit" name="submit" value="Submit" onClick={handleClick} />
          </div>

        
      </form>
    </div>
    // <>
    // <h1>{greeting}</h1>
    // <button onClick={()=>{
    //     setGreeting("bye world")
    // }}>Change</button>
    // </>
  );
};

export default RegisterManager;