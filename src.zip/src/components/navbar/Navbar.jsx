import "./navbar.css"
import { faPerson, faTreeCity}from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useNavigate } from "react-router-dom";
//import logo1 from "./logo.jpg";
const Navbar = () => {
  const navigate = useNavigate();
  const handleSearch = () => {
  navigate("/userlogin");
};
const handleSearch2 = () => {
  navigate("/managerLogin");
};
  return (
    <div className="navbar">
      <div className="navContainer">
      <span className="logo"><FontAwesomeIcon icon={faTreeCity} /> Yash Hotels</span>
        <div className="navItems">
          <button className="navButton" onClick={handleSearch2}> <FontAwesomeIcon icon={faPerson}/> List your property</button>
          <button className="navButton" onClick={handleSearch}> <FontAwesomeIcon icon={faPerson} /> Register/Sign in</button>
        </div>
      </div>
    </div>
  )
}

export default Navbar