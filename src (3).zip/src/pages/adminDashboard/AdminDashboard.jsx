import { RecordVoiceOverSharp } from '@material-ui/icons';
import {  useNavigate } from 'react-router-dom';
import { faPerson,faParachuteBox } from '@fortawesome/free-solid-svg-icons';
import React from 'react';
import NavbarDashboard from "../../components/navbar/NavbarDashBoard"
import { useState, useEffect } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import "./AdminDashboard.css"

import { getData,setData } from '../../SessionMaintain';
function AdminDashboard() {
    const [managers, setManager] = useState([]);
    const [users, setUser] = useState([]);
    const[id,setId] = useState("");
    let navigate=useNavigate();
    useEffect(() => {
        fetch("http://localhost:8080/getManagers")
            .then(res => res.json())
            .then((result) => {
                setManager(result);
            }
            )
    }, [])
    useEffect(() => {
        fetch("http://localhost:8080/allUsers")
            .then(res => res.json())
            .then((result) => {
                setUser(result);
            }
            )
    }, [])
    const deleteManager=()=>{
        fetch("http://localhost:8080/deleteManager/"+id)
            .then(res=>res.text())
            .then((result) => {
                alert("Manager Account has been deleted" + id)
            }
            )

    }
    const editManager= ()=>{
        navigate("/editManager")
        const data={Role:3,ID:id};
        setData(JSON.stringify(data));
    }
    const editUser= ()=>{
        navigate("/editUser")
        const data={Role:3,ID:id};
        setData(JSON.stringify(data));

    }
    const deleteUser=()=>{
        fetch("http://localhost:8080/delete/"+id)
        .then(res=>res.text())
        .then((result) => {
            alert("User Account has been deleted" + id)
        }
        )

        
    }

    if (getData() === "admin") {
        return (
            <>
                <NavbarDashboard />
                <section><br></br>
                    <div><center><h1><span style={{ color: "#003580" }}>Manager List</span></h1></center></div><br></br>
                    <div className="card-container">
                        <div className="card">
                            <div><table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col">Client Name</th>
                                        <th scope="col">Mobile Number</th>
                                        <th scope="col">Email</th>
                                        <th scope="col">Hotel Name</th>
                                        <th scope="col">Hotel Registration Number</th>
                                        <th scope="col">Edit</th>
                                        <th scope="col">Delete</th>
                                    </tr>
                                </thead>
                                {managers.map(manager => (
                                    <tbody key={manager.registrationNumber}>

                                        <tr >
                                            <td>{manager.clientName}</td>
                                            <td>{manager.mobileNumber}</td>
                                            <td>{manager.email}</td>
                                            <td>{manager.hotelName}</td>
                                            <td>{manager.registrationNumber}</td>
                                            <td><button type="button" onMouseOver={()=>setId(manager.registrationNumber)} onClick={() => editManager()}>Edit</button></td>
                                            <td><button type="button" onMouseOver={()=>setId(manager.registrationNumber)} onClick={() => deleteManager()}>Delete</button></td>
                                        </tr>
                                    </tbody>))}

                            </table>
                            </div>
                        </div>
                    </div>

                     <div><center><h1><span style={{ color: "#003580" ,width:"100%"}}>User List</span></h1></center></div><br></br>
                    <div className="card-container">
                        <div className="card">
                            <div><table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col">User Name</th>
                                        <th scope="col">Age</th>
                                        <th scope="col">Email</th>
                                        <th scope="col">Mobile Number</th>
                                        <th scope="col">Address</th>
                                        <th scope="col">Profession</th>
                                        <th scope="col">Edit</th>
                                        <th scope="col">Delete</th>
                                    </tr>
                                </thead>
                                {users.map(user => (
                                    <tbody key={user.email}>

                                        <tr >
                                            <td>{user.name}</td>
                                            <td>{user.age}</td>
                                            <td>{user.email}</td>
                                            <td>{user.mobileNumber}</td>
                                            <td>{user.address}</td>
                                            <td>{user.profession}</td>
                                            <td><button onMouseOver={()=>setId(user.email)} onClick={() => editUser()}>Edit</button></td>
                                            <td><button onMouseOver={()=>setId(user.email)} onClick={() => deleteUser()}>Delete</button></td>
                                        </tr>
                                    </tbody>))}

                            </table>
                            </div>
                        </div>
                    </div>
                </section>
            </>

        )
    }
}
export default AdminDashboard;
