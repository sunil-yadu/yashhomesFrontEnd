import styled from "styled-components";

import React, { Component, useEffect, useReducer, useState } from 'react';

import Navbar from "../../components/navbar/Navbar";
import Footer from "../../components/footer/Footer";
import MailList from "../../components/mailList/MailList";
import { useNavigate } from "react-router-dom";
import { setData,getData } from "../../SessionMaintain";
//import "./register.css";



const Container = styled.div`
  width: 100vw;
  height: 100vh;
  background: linear-gradient(
      rgba(255, 255, 255, 0.5),
      rgba(255, 255, 255, 0.5)
    ),
    url("https://images.pexels.com/photos/6984661/pexels-photo-6984661.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940")
      center;
  background-size: cover;
  display: flex;
  align-items: center;
  background-image: url("https://www.vobss.com/wp-content/uploads/2022/07/aesthetic-beach-wallpaper-vobss.jpg");
  justify-content: center;
  
`;

const Wrapper = styled.div`
  width: 40%;
  padding: 20px;
  background-color: white;
  border-radius: 20px;
 
  
 
`;

const Title = styled.h1`
  font-size: 24px;
  font-weight: 300;
`;

const Form = styled.form`
  display: flex;
  flex-wrap: wrap;
`;

const Input = styled.input`
  flex: 1;
  min-width: 40%;
  margin: 20px 10px 0px 0px;
  padding: 10px;
`;

const Agreement = styled.span`
  font-size: 12px;
  margin: 20px 0px;
`;

const Button = styled.button`
  width: 99%;
  border: none;
  padding: 15px 20px;
  background-color: #003580;
  color: white;
  cursor: pointer;
`;

const Register = () => {
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [mobileNumber, setMobileNumber] = useState("");
  var [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [profession, setProfession] = useState("");
  const [address, setAddress] = useState("");
  let navigate=useNavigate();
  const handleClick1 = (event) => {
    event.preventDefault()
    const get=JSON.parse(getData())
    email=get.ID
    const client = { name, age, mobileNumber, email, password, profession, address }
            console.log(client);
            fetch("http://localhost:8080/editUser", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(client)
            }).then(res => res.text())
              .then((result) => {
                alert(result);
                setData("admin")
                navigate("/adminDashboard");
              });
          }
  return (
    <><Navbar /><Container>
      <Wrapper>

        <Title>Edit User</Title>
        <Form>
          <Input placeholder="full name" id="name" name="name"
            value={name} onChange={(event) => {
              setName(event.target.value)
            }}
            type={"text"} required />
          <Input placeholder="age" id="age" name="age"
            value={age} onChange={(event) => {
              setAge(event.target.value)
            }}
            required />
          <Input placeholder="contact no." id="mobileNumber" name="mobileNumber"
            value={mobileNumber} onChange={(event) => {
              setMobileNumber(event.target.value)
            }}
            type={"tel"} required />
          <Input placeholder="profession" id="profession" name="profession"
            value={profession} onChange={(event) => {
              setProfession(event.target.value)
            }}
            required />
          <Input placeholder="password" id="password" name="password"
            value={password} onChange={(event) => {
              setPassword(event.target.value)
            }}
            type={"password"} required />
          <Input placeholder="Address" id="address" name="address"
            value={address} onChange={(event) => {
              setAddress(event.target.value)
            }}
            type={"text"} required />
          <Agreement>
            By creating an account, I consent to the processing of my personal
            data in accordance with the <b>PRIVACY POLICY</b>
          </Agreement>
          <Button onClick={handleClick1}>Submit Edited User Details</Button>
        </Form>
      </Wrapper>
    </Container>
      <MailList />
      <Footer /></>
  );
};

export default Register;
