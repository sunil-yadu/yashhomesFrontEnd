import styled from "styled-components";
import { useState } from "react";
import { Link as L } from "react-router-dom";
import { SettingsSystemDaydreamOutlined } from "@material-ui/icons";
import React from 'react';
import { useNavigate } from "react-router-dom";
import Navbar from "../../components/navbar/Navbar";
import MailList from "../../components/mailList/MailList";
import Footer from "../../components/footer/Footer";
import {getData, setData} from "../../SessionMaintain";


const Container = styled.div`
  width: 100vw;
  height: 100vh;
  background: linear-gradient(
      rgba(255, 255, 255, 0.5),
      rgba(255, 255, 255, 0.5)
    ),
    url("https://images.pexels.com/photos/6984650/pexels-photo-6984650.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940")
      center;
  background-size: cover;
  display: flex;
  align-items: center;
  background-image: url("https://www.vobss.com/wp-content/uploads/2022/07/aesthetic-beach-wallpaper-vobss.jpg");
  justify-content: center;
`;

const Wrapper = styled.div`
  width: 25%;
  padding: 20px;
  background-color: white;

`;

const Title = styled.h1`
  font-size: 24px;
  font-weight: 300;
`;

const Form = styled.form`
  display: flex;
  flex-direction: column;
`;

const Input = styled.input`
  flex: 1;
  min-width: 40%;
  margin: 10px 0;
  padding: 10px;
`;

const Button = styled.button`
  width: 100%;
  border: none;
  padding: 15px 20px;
  background-color: #003580;
  color: white;
  cursor: pointer;
  margin-bottom: 10px;
`;

const Link = styled.a`
  margin: 5px 0px;
  font-size: 12px;
  text-decoration: underline;
  cursor: pointer;
`;

const Login = () => {
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [email, setEmail] = useState("");
 const handleClick=()=>{
  if(password==="12345"|| email==="taha.sanawad@yash.com"){
      alert("Hello Admin--> You will be redirected to admin Dashboard");
      navigate("/adminDashboard");
      setData("admin");
  }
  else{
    alert("Incorrect Admin Details");
  }
 }

 const [emailError, setEmailError] = useState("");



//  const validEmail = (e) => {
//   let emailPattern = /^[a-zA-Z0-9]+@+[a-zA-Z0-9]+.+[A-z]/;
//   if (e.target.value === "" || !emailPattern.test(e.target.value)) {
//      setEmail(e.target.value);
//      setEmailError("");
//   } else {
//     console.log("please enter a valid Email");
//     setEmailError("Please enter a valid Email");
//   }
// };


// const [passwordError, setPasswordError] = useState("");
// const validPassword = (e) => {
   
//   let passwordPattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,20}$/;

//   setPassword(e.target.value);
//   if (!passwordPattern.test(e.target.value)) {
//     console.log("please enter strong password");
//     setPasswordError("Please enter strong password(A-Z, a-z,@#!$.,1234..)");
//   } else {
//     console.log("success");
//     setPasswordError("");
//   }

// };



  return (
    <><Navbar/>
    <Container>
      <Wrapper>
        <Title> ADMIN-LOGIN</Title>
        <Form>

          <Input placeholder="user Email" id="email" type={"email"} name="email" required 
          value={email}
              onChange={validEmail} />
            <span style={{ color: "red", fontSize:"13px" }}>{emailError}</span>


          <Input id="password" value={password} onChange={(event) => {
              setPassword(event.target.value)}} 
              placeholder="password" />
          <Button onClick={handleClick} > LOGIN</Button>
          <Link>DO NOT YOU REMEMBER THE PASSWORD?</Link>
        </Form>
      </Wrapper>
    </Container>
    <MailList/>
    <Footer/>
    </>
  );
};

export default Login;