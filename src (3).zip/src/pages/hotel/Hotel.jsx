import "./hotel.css";
import Navbar from "../../components/navbar/Navbar";
import Header from "../../components/header/Header";
import MailList from "../../components/mailList/MailList";
import Footer from "../../components/footer/Footer";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faCircleArrowLeft,
  faCircleArrowRight,
  faCircleXmark,
  faLocationDot,
} from "@fortawesome/free-solid-svg-icons";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {getData} from "../../SessionMaintain";

const Hotel = () => {
  const [slideNumber, setSlideNumber] = useState(0);
  const [open, setOpen] = useState(false);

  const photos = [
    {
      src: "https://r1imghtlak.mmtcdn.com/a5e4e758783811e789f00a4cef95d023.jpg",
    },
    {
      src: "https://r1imghtlak.mmtcdn.com/5652be6e003511e9a5160242ac110002.jpg?&output-quality=75&downsize=910:612&crop=910:612;0,13&output-format=jpg",
    },
    {
      src: "https://r1imghtlak.mmtcdn.com/58eb2afc003611e9806a0242ac110005.jpg?&output-quality=75&downsize=910:612&crop=910:612;4,0&output-format=jpg",
    },
    {
      src: "https://images.luxuryescapes.com/q_auto:eco/0tvh0es159tpnbaa3axo.jpeg",
    },
    {
      src: "https://dynamic-media-cdn.tripadvisor.com/media/photo-o/0e/7c/03/89/entrance-to-the-leela.jpg?w=1200&h=-1&s=1",
    },
    {
      src: "https://dynamic-media-cdn.tripadvisor.com/media/photo-o/0f/eb/6d/59/hotel-heritage-high.jpg?w=1200&h=-1&s=1",
    },
  ];

  const handleOpen = (i) => {
    setSlideNumber(i);
    setOpen(true);
  };

  const handleMove = (direction) => {
    let newSlideNumber;

    if (direction === "l") {
      newSlideNumber = slideNumber === 0 ? 5 : slideNumber - 1;
    } else {
      newSlideNumber = slideNumber === 5 ? 0 : slideNumber + 1;
    }

    setSlideNumber(newSlideNumber)
  };
  const navigate = useNavigate();
  const check=''+getData();
  const handleClick = (event) => {
    if("null"!==check){
      console.log(getData());
     navigate("/mumbaiBook1");
    }else{
      console.log(getData());
      //alert("You first need to login before booking a hotel");
      navigate("/userlogin");
    }

  }

  return (
    <div>
      <Navbar />
      <Header type="list" />
      <div className="hotelContainer">
        {open && (
          <div className="slider">
            <FontAwesomeIcon
              icon={faCircleXmark}
              className="close"
              onClick={() => setOpen(false)}
            />
            <FontAwesomeIcon
              icon={faCircleArrowLeft}
              className="arrow"
              onClick={() => handleMove("l")}
            />
            <div className="sliderWrapper">
              <img src={photos[slideNumber].src} alt="" className="sliderImg" />
            </div>
            <FontAwesomeIcon
              icon={faCircleArrowRight}
              className="arrow"
              onClick={() => handleMove("r")}
            />
          </div>
        )}
        <div className="hotelWrapper">
          <button className="bookNow" onClick={handleClick}>Reserve or Book Now!</button>
          <h1 className="hotelTitle">The Leela Mumbai - Resort Style Business Hotel</h1>
          <div className="hotelAddress">
            <FontAwesomeIcon icon={faLocationDot} />
            <span>Versova Beach Road</span>
          </div>
          <span className="hotelDistance">
            Excellent location – 4.2Km from center | 1.9Km from Airport
          </span>
          <span className="hotelPriceHighlight">
            Book your stay and get a free airport taxi
          </span>
          <div className="hotelImages">
            {photos.map((photo, i) => (
              <div className="hotelImgWrapper" key={i}>
                <img
                  onClick={() => handleOpen(i)}
                  src={photo.src}
                  alt=""
                  className="hotelImg"
                />
              </div>
            ))}
          </div>
          <div className="hotelDetails">
            <div className="hotelDetailsTexts">
              <h1 className="hotelTitle">Stay in the heart of City</h1>
              <p className="hotelDesc">
              Make yourself at home in one of the 394 individually decorated guestrooms, featuring refrigerators and iPod docking stations. Your bed comes with down comforters and premium bedding. 32-inch flat-screen televisions with premium TV channels provide entertainment, with wired and wireless Internet access available for a surcharge. Private bathrooms with separate bathtubs and showers feature deep soaking bathtubs and rainfall showerheads.
              <br/>
              <br/>
              <h3>Facilities</h3>
              <br/>
              Pamper yourself with a visit to the spa, which offers massages, body treatments, and facials. You can take advantage of recreational amenities such as a health club, an outdoor pool, and a spa tub. Additional features at this hotel include wireless Internet access (surcharge), concierge services, and gift shops/newsstands.
              </p>
            </div>
            <div className="hotelDetailsPrice">
              <h1>Perfect for a 5-night stay!</h1>
              <span>
                Located in the real heart of Mumbai, this property has an
                excellent hospitality score of 9.8!
              </span>
              <h2>
                <b>₹38,331/total</b> (5 nights)
              </h2>
              <button onClick={handleClick}>Reserve or Book Now!</button>
            </div>
          </div>
        </div>
        <MailList />
        <Footer />
      </div>
    </div>
  );
};

export default Hotel;