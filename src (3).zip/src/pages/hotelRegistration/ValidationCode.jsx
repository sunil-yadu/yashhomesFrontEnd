import { useState } from "react";
import styled from "styled-components";

const ValidationCode = () => {
  
    const [nameError, setNameError] = useState("");
    const [name,setName]=useState("");

    const [surnameError, setSurnameError] = useState("");
    const [surname,setSurname]=useState("");

    const [emailError, setEmailError] = useState("");
    const [email,setEmail]=useState("");

    const [passwordError, setPasswordError] = useState("");
    const [password,setPassword]=useState("");

    const [addressError, setAddressError] = useState("");
    const [address,setAddress]=useState("");

    const [mobileNumberError, setMobileNumberError] = useState("");
    const [mobileNumber,setMobileNumber]=useState("");

    const [registrationNumberError, setRegistrationNumberError] = useState("");
    const [registrationNumber,setRegistrationNumber]=useState("");

    const [hotelNameError, setHotelNameError] = useState("");
    const [hotelName,setHotelName]=useState("");

    const [totalRoomError, setTotalRoomError] = useState("");
    const [totalRoom,setTotalRoom]=useState("");

    const [totalAcRoomError, setTotalAcRoomError] = useState("");
    const [totalAcRoom,setTotalAcRoom]=useState("");

    const [totalNonAcRoomError, setTotalNonAcRoomError] = useState("");
    const [totalNonAcRoom,setTotalNonAcRoom]=useState("");

    const [chargesError, setChargesError] = useState("");
    const [charges,setCharges]=useState("");

    const [foodIncludeError, setFoodIncludeError] = useState("");
    const [foodInclude,setFoodInclude]=useState("");

    const [barError, setBarError] = useState("");
    const [bar,setBar]=useState("");

    const [ageError, setAgeError] = useState("");
    const [age, setAge] = useState("");




    const validAge = (e) => {
      let agePattern = /^\d+$/;
  
      if(e.target.value==="" || agePattern.test(e.target.value)){
        setAge(e.target.value)
        setAgeError("")
      }
      else{
        setAgeError("Please enter value age in number")
      }
    }
    

const validName = (e) => {

    let namePattern = /^[a-zA-Z]+$/;
    if (e.target.value === "" || namePattern.test(e.target.value)) {
       setName(e.target.value);
       setNameError("")
    } else {
      console.log("please enter a valid name");
      setNameError("Please enter a valid name");
    }

  };

  const validSurname = (e) => {
    let surNamePattern = /^[a-zA-Z]+$/;
    if (e.target.value === "" || surNamePattern.test(e.target.value)) {
       setSurname(e.target.value);
       setSurnameError("")
    } else {
      console.log("please enter a valid surname");
      setSurnameError("Please enter a valid surName");
    }
  };

  const validEmail = (e) => {
    let emailPattern = /^[a-zA-Z0-9]+@+[a-zA-Z0-9]+.+[A-z]/;
    if (e.target.value === "" || !emailPattern.test(e.target.value)) {
       setEmail(e.target.value);
       setEmailError("");
    } else {
      console.log("please enter a valid Email");
      setEmailError("Please enter a valid Email");
    }
  };

  const validPassword = (e) => {
   
    let passwordPattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,20}$/;

    setPassword(e.target.value);
    if (!passwordPattern.test(e.target.value)) {
      console.log("please enter strong password");
      setPasswordError("Please enter strong password(A-Z, a-z,@#!$.,1234..)");
    } else {
      console.log("success");
      setPasswordError("");
    }

  };

  

const validAddress = (e) => {
    let addressPattern = /^[A-Za-z0-9]*$/;
    if (e.target.value === "" || addressPattern.test(e.target.value)) {
       setAddress(e.target.value);
       setAddressError("")
    } else {
      console.log("please enter a valid Address");
      setAddressError("Please enter a valid Address");
    }
  };

  const validMobileNumber = (e) => {
    

    let contactPattern = /^\d+$/;

    if (e.target.value === "" || contactPattern.test(e.target.value)) {
      setMobileNumber(e.target.value);
      setMobileNumberError("")
    }
    console.log("please enter a valid no.");
    setMobileNumberError("please enter a valid number");

  };

  const validRegistrationNumber = (e) => {
    let regNumPattern = /^[A-Za-z0-9]*$/;
        
    if (regNumPattern.test(e.target.value)) {
        setRegistrationNumber(e.target.value);
        setRegistrationNumberError("");
    }
 else {
      console.log("please enter a valid RegistrationNumber");
      setRegistrationNumberError("Please enter a valid RegistrationNumber");
    }
  };
  
  const validHotelName = (e) => {
    let hotelNamePattern = /^[A-Za-z0-9]*$/;
    if (e.target.value === "" || hotelNamePattern.test(e.target.value)) {
       setHotelName(e.target.value);
       setHotelNameError("")
    } else {
      console.log("please enter a valid HotelName");
      setHotelNameError("Please enter a valid HotelName");
    }
  };

  const validTotalRoom = (e) => {

    let roomsPattern = /^\d+$/;

        if (e.target.value === "" || roomsPattern.test(e.target.value)) {
                setTotalRoom(e.target.value);
                setTotalRoomError("")
        } else {
      console.log("please enter a valid total Room");
      setTotalRoomError("Please enter valid total room");
    }
  };

  const validTotalAcRoom = (e) => {

    
    let totalAcRoomPattern = /^\d+$/;

        if (e.target.value === "" || totalAcRoomPattern.test(e.target.value)) {
                setTotalAcRoom(e.target.value);
                setTotalAcRoomError("")
        } else {
          console.log("please enter a valid total Available Ac Room");
          setTotalAcRoomError("Please enter valid total Available Ac rooms");
        }

  };

  const validTotalNonAcRoom = (e) => {
    let totalNonAcroomPattern =  /^\d+$/;
    if (e.target.value === "" || totalNonAcroomPattern.test(e.target.value)) {
       setTotalNonAcRoom(e.target.value);
       setTotalNonAcRoomError("")
    } else {
      console.log("please enter a valid total Available Non Ac Room");
      setTotalNonAcRoomError("Please enter valid total Available Non Ac rooms");
    }
  };

  const validCharges = (e) => {
    let chargesPattern = /^\d+$/;
    if (e.target.value === "" || chargesPattern.test(e.target.value)) {
       setCharges(e.target.value);
       setChargesError("")
    } else {
      console.log("please enter a valid Charges");
      setChargesError("Please enter valid Charges");
    }
  };

  // const validFood = (e) => {
  //      alert(e.target.value)
  //      setFoodInclude(e.target.value);
       
     
  // };

  // const validBar = (e) => {
  //   let barPattern = /^[a-zA-Z]+$/;
  //   if (e.target.value === "" || barPattern.test(e.target.value)) {
  //      setBar(e.target.value);
  //      setBarError("")
  //   } else {
  //     console.log("please enter Yes / No");
  //     setBarError("Please enter Yes / No");
  //   }
  // };

 

  





return (

    <div>
        <div>

           <input placeholder="Enter Name Name"
            type={"text"}
            value={name}
            onChange={validName}
            required />

          <span style={{ color: "red", fontSize:"13px" }}>{nameError}</span>
        </div>
        <div>

           <input placeholder="Enter Surname"
            type={"text"}
            value={surname}
            onChange={validSurname}
            required />

          <span style={{ color: "red", fontSize:"13px" }}>{surnameError}</span>
        </div>
        <div>

        <input placeholder="enter age" type={"tel"} maxLength={2} id="age" name="age"
            value={age} onChange={validAge}
            required />
            <span style={{color:"red"}}>{ageError}</span>
            </div>

        <div>

           <input placeholder="Enter Email"
            type={"email"}
            value={email}
            onChange={validEmail}
            required />

          <span style={{ color: "red", fontSize:"13px" }}>{emailError}</span>
        </div>
        <div>

           <input placeholder="Enter Password"
            type={"text"}
            value={password}
            onChange={validPassword}
            required />

          <span style={{ color: "red", fontSize:"13px" }}>{passwordError}</span>
        </div>
        
        <div>

           <input placeholder="Enter MobileNumber"
            type={"tel"} maxLength={10}
            value={mobileNumber}
            onChange={validMobileNumber}
            required />

          <span style={{ color: "red", fontSize:"13px" }}>{mobileNumberError}</span>
        </div>

       

         <div>

           <input placeholder="Enter Address"
            type={"text"}
            value={address}
            onChange={validAddress}
            required />

          <span style={{ color: "red", fontSize:"13px" }}>{addressError}</span>
        </div>


        


        <div>

           <input placeholder="Enter hotel Registration Number"
            type={"text"}
            value={registrationNumber}
            onChange={validRegistrationNumber}
            required />

          <span style={{ color: "red", fontSize:"13px" }}>{registrationNumberError}</span>
        </div>


        <div>

           <input placeholder="Enter HotelName"
            type={"text"}
            value={hotelName}
            onChange={validHotelName}
            required />

          <span style={{ color: "red", fontSize:"13px" }}>{hotelNameError}</span>
        </div>

        <div>

           <input placeholder="Enter Total Rooms"
            type={"text"}
            value={totalRoom}
            onChange={validTotalRoom}
            required />

          <span style={{ color: "red", fontSize:"13px" }}>{totalRoomError}</span>
        </div>

        <div>

           <input placeholder="Enter Total Available Ac Rooms"
            type={"text"}
            value={totalAcRoom}
            onChange={validTotalAcRoom}
            required />

          <span style={{ color: "red", fontSize:"13px" }}>{totalAcRoomError}</span>
        </div>

        <div>

           <input placeholder="Enter Total Available Non Ac Rooms"
            type={"text"}
            value={totalNonAcRoom}
            onChange={validTotalNonAcRoom}
            required />

          <span style={{ color: "red", fontSize:"13px" }}>{totalNonAcRoomError}</span>
        </div>

        
        <div>

           <input placeholder="Enter Charges"
            type={"text"}
            value={charges}
            onChange={validCharges}
            required />

          <span style={{ color: "red", fontSize:"13px" }}>{chargesError}</span>
        </div>

        
        <div>
          <select>
            <h3>Food Included </h3>
            <option value="">Food Include -Yes/No</option>
            <option value={foodInclude} onChange={(event)=>{setFoodInclude(event.target.value)}}>Yes</option>
            <option value={foodInclude} onChange={(event)=>{setFoodInclude(event.target.value)}}>No</option>

          </select>
          
        </div>

        
        <div>
          <select>
            <h3>Bar Included </h3>
            <option value="">Bar Include -Yes/No</option>
            <option value={bar} onChange={(event)=>{setBar(event.target.value)}}>Yes</option>
            <option value={bar} onChange={(event)=>{setBar(event.target.value)}}>No</option>

          </select>
          
        </div>

        

          </div>
);
};

export default ValidationCode;

