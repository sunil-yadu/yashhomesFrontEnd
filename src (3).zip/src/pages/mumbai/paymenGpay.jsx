import React from 'react'
import { useState } from 'react';
import GooglePayButton from '@google-pay/button-react';
import Navbar from '../../components/navbar/Navbar';
import MailList from "../../components/mailList/MailList";
import Footer from '../../components/footer/Footer';
import {getData,setData} from "../../SessionMaintain"
import { useNavigate } from 'react-router-dom';
import { setISODay } from 'date-fns';
function PaymenGpay() {
    const[payment,setPayment]=useState("")
    const get = JSON.parse(getData());
    const handleClick=()=>{
    let id=get.BookingId
    //alert(id)
    let api = "http://localhost:8080/getDetails/"+id;
    fetch(api, {
        method: "POST",
        // headers: { "Content-Type": "application/json" },
        // body: JSON.stringify(inputFields)
      }).then(res => res.text())
        .then((result) => {
            alert(result)
            setPayment(result)
          const data={Role:get.Role,mail:get.mail,BookingId:result};
          setData(JSON.stringify(data));
        });
    }
    return (
<><Navbar/>
        <div className="App">
            <h1>Payment using Gpay</h1>
            {/* <h1>Payment using Gpay<button onClick={handleClick}>PLEASE!! click here to proceed payment</button></h1> */}
            <hr />
            <GooglePayButton
                environment="TEST"
                paymentRequest={{
                    apiVersion: 2,
                    apiVersionMinor: 0,
                    allowedPaymentMethods: [
                        {
                            type: 'CARD',
                            parameters: {
                                allowedAuthMethods: ['PAN_ONLY', 'CRYPTOGRAM_3DS'],
                                allowedCardNetworks: ['MASTERCARD', 'VISA'],
                            },
                            tokenizationSpecification: {
                                type: 'PAYMENT_GATEWAY',
                                parameters: {
                                    gateway: 'example',
                                    gatewayMerchantId: 'exampleGatewayMerchantId',
                                },
                            },
                        },
                    ],
                    merchantInfo: {
                        merchantId: '12345678901234567890',
                        merchantName: 'Demo Merchant',
                    },
                    transactionInfo: {
                        totalPriceStatus: 'FINAL',
                        totalPriceLabel: 'Total',
                        totalPrice: "1",
                        currencyCode: 'USD',
                        countryCode: 'US',
                    },
                    shippingAddressRequired: true,
                    callbackIntents: ['SHIPPING_ADDRESS', 'PAYMENT_AUTHORIZATION'],
                }}
                onLoadPaymentData={paymentRequest => {
                    console.log('Success', paymentRequest);
                }}
                onPaymentAuthorized={paymentData => {
                    console.log('Payment Authorised Success', paymentData)
                    return { transactionState: 'SUCCESS' }
                }
                }
                onPaymentDataChanged={paymentData => {
                    console.log('On Payment Data Changed', paymentData)
                    return {}
                }
                }
                existingPaymentMethodRequired='false'
                buttonColor='black'
                buttonType='Buy'
            />
        </div>
        <MailList/>
        <Footer/>
        </>
    );
}
export default PaymenGpay;
  

