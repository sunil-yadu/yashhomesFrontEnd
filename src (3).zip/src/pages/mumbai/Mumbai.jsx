import React from 'react'
import Navbar from '../../components/navbar/Navbar';
import MailList from "../../components/mailList/MailList";
import Footer from '../../components/footer/Footer';
//import Header from '../../components/header/Header';
import {useNavigate} from "react-router-dom";
const Mumbai = () => {
  const navigate=useNavigate();
  const handleClick = (event) => {
    navigate("/hotels/df")
  }
    return (
        <div>
            <Navbar />
            <div className="searchItem">
      <img
        src="https://lh3.googleusercontent.com/p/AF1QipOLNIaobilE98k-2VCKwqbPAAVSGtnHgpJFKlBY=w592-h404-n-k-rw-no-v1"
        alt=""
        className="siImg"
      />
      <div className="siDesc">
        <h1 className="siTitle">The Leela Mumbai - Resort Style Business Hotel</h1>
        <span className="siDistance">Near by Mumbai International Airport</span>
        <span className="siTaxiOp">Free airport taxi</span>
        <span className="siSubtitle">
        Sophisticated hotel with stylish restaurants & bars, plus an outdoor pool & a high-end spa.
        </span>
        <span className="siFeatures">
          <b>5 star</b> | Top-rated | Great pool | Great location
        </span>
        <span className="siCancelOp">Free cancellation </span>
        <span className="siCancelOpSubtitle">
          You can cancel later, so lock in this great price today!
        </span>
      </div>
      <div className="siDetails">
        <div className="siRating">
          <span>Outstanding</span>
          <button>9.5</button>
        </div>
        <div className="siDetailTexts">
          <span className="siPrice">Starts from Rs. 8000 per night </span>
          <span className="siTaxOp">Includes taxes and fees</span>
          <button className="siCheckButton" onClick={handleClick} >Book Noww!!</button>
        </div>
      </div>
    </div>


    <div className="searchItem">
      <img
        src="https://lh3.googleusercontent.com/p/AF1QipPgIWRdCmLgUqrjt-88_Ec2VXXkJQmt_Xoa5iSf=w592-h404-n-k-rw-no-v1"
        alt=""
        className="siImg"
      />
      <div className="siDesc">
        <h1 className="siTitle">ITC Maratha, a Luxury Collection Hotel</h1>
        <span className="siDistance">Ashok Nagar, Andheri East</span>
        <span className="siTaxiOp">Free airport taxi</span>
        <span className="siSubtitle">
        Grand hotel offering refined quarters, plus upscale dining, an outdoor pool & a spa.
        </span>
        <span className="siFeatures">
          <b>5 star</b> | Breakfast | Free wifi | Outdoor pool
        </span>
        <span className="siCancelOp">Free cancellation </span>
        <span className="siCancelOpSubtitle">
          You can cancel later, so lock in this great price today!
        </span>
      </div>
      <div className="siDetails">
        <div className="siRating">
          <span>Outstanding</span>
          <button>9.5</button>
        </div>
        <div className="siDetailTexts">
          <span className="siPrice">Starts from Rs. 8387 per night </span>
          <span className="siTaxOp">Includes taxes and fees</span>
          <button className="siCheckButton">Book Noww!!</button>
        </div>
      </div>
    </div>
    

            <MailList/>
            <Footer/>
        </div>
    );
};

export default Mumbai;












/*export default function Mumbai() {
  return (
    <><Navbar /><div>Mumbai</div><MailList /><Footer /></>
  )
}*/
