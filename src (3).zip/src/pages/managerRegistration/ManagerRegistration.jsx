import { useState } from "react";
import styled from "styled-components";
import Navbar from "../../components/navbar/Navbar";
import MailList from "../../components/mailList/MailList";
import Footer from "../../components/footer/Footer";
import { useNavigate } from "react-router-dom";
import { getData, setData } from "../../SessionMaintain";

const Container = styled.div`
  width: 100vw;
  height: 100vh;
  background: linear-gradient(
      rgba(255, 255, 255, 0.5),
      rgba(255, 255, 255, 0.5)
    ),
    url("https://images.pexels.com/photos/6984661/pexels-photo-6984661.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940")
      center;
  background-size: cover;
 
  background-repeat: no-repeat;
  background-color: #9fe8e3;
  
   background-position: center center;
   
   
  display: flex;
  align-items: center;
  justify-content: center;
`;

const Wrapper = styled.div`
  width: 30%;
  padding: 20px;
  background-color: white;
 
  border-radius: 20px;
  
  
  
  
`;

const Title = styled.h1`
  font-size: 24px;
  font-weight: 3000;
  text-align: center;
  color: #0071c2;
`;

const Form = styled.form`
  display: flex;  
  flex-wrap: wrap;
  flex-direction: column;
`;

const Input = styled.input`
  flex: 1;
  min-width: 40%;
  margin: 10px 10px 0px 0px;
  padding: 5px;
`;

const Agreement = styled.span`
  font-size: 12px;
  margin: 20px 0px;
`;

const Button = styled.button`
  width: 40%;
  border: none;
  padding: 15px 20px;
  background-color: #0071c2;
  color: white;
  cursor: pointer;
`;

const ManagerRegister = () => {
  const [hotelName, setHotelName] = useState("");
  const [clientName, setClientName] = useState("");
  const [mobileNumber, setMobileNumber] = useState("");
  const [email, setEmail] = useState("");
  const [registrationNumber, setRegistrationNumber] = useState("");
  const [password, setPassword] = useState("");
  const [nameError, setNameError] = useState("");
  const [error, setError] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const navigate=useNavigate();

  const submitHandler = (e) => {
    e.preventDefault();
    console.log("submitted");
  };

  const validClientName = (e) => {
    let namePattern = /^[a-zA-Z]+$/;
    if (e.target.value === "" || namePattern.test(e.target.value)) {
      return setClientName(e.target.value);
    } else {
      console.log("please enter a valid name");
      setNameError("Please enter a valid name");
    }
  };

  const validateMobileNumber = (e) => {
    let contactPattern = /^\d+$/;

    if (e.target.value === "" || contactPattern.test(e.target.value)) {
      return setMobileNumber(e.target.value);
    }
    else{
    console.log("please enter a  valid no.");
    setError("please enter a valid number");
    }
  };

  const validatePassword = (e) => {
    let passwordPattern =
      /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,20}$/;
    setPassword(e.target.value);
    if (!passwordPattern.test(e.target.value)) {
      console.log("please enter strong password");
      setPasswordError("please enter strong password");
    } else {
      console.log("success");
      setPasswordError("");
    }
  };

  // const validOtp = () => {
  // };

  // const getOTP = (event) => {
  //     event.preventDefault()
  //     const client = {emailId}
  //     console.log(client);
  //     fetch("http://localhost:8080/getByManagementEmail", {
  //       method: "POST",
  //       headers: { "Content-Type": "application/json" },
  //       body: JSON.stringify(client)
  
  //     })
  //       .then(res => res.text())
  //           .then((result) => {
  //             alert(result);
  //           });
  //     }
const handleRegister = (event) => {
  if(hotelName===""||clientName===""||mobileNumber===""||email===""||registrationNumber===""||password===""){
    alert("fields cant be empty")
  }else{
      event.preventDefault()
      const client = {hotelName,clientName,mobileNumber,email,registrationNumber,password}
      alert(JSON.stringify(client))
      fetch("http://localhost:8080/saveManager", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(client)
  
      })
        .then(res => res.text())
            .then((result) => {
              if(result==="Data saved"){
              alert(result);
              navigate("/managerLogin")
              }
              else{
                alert("someError occured")
              }
            });
      }
    }
  

  return (
    <><Navbar /><Container>
      <Wrapper>
        <Title>Manager Registration Form</Title>
        <Form onSubmit={submitHandler}>
          <Input
            placeholder="Hotel Name"
            type={"text"}
            value={hotelName}
            onChange={(e) => {
              setHotelName(e.target.value);
            } }
            required />
          <Input
            placeholder="Enter Client Name"
            type={"text"}
            value={clientName}
            onChange={validClientName}
            required />
         
          <Input
            placeholder="Registration Number"
            type={"text"}
            value={registrationNumber}
            onChange={(e) => {
              setRegistrationNumber(e.target.value);
            } }
            required />
          <Input
            placeholder="Contact Number"
            maxLength={10}
            type={"tel"}
            value={mobileNumber}
            onChange={validateMobileNumber}
            required />
          
          <Input
            placeholder="Email ID"
            type={"email"}
            value={email}
            onChange={(e) => {
              setEmail(e.target.value);
            } }
            required />
          <Input
            placeholder="Password"
            type={"password"}
            value={password}
            onChange={validatePassword}
            required />
         <br/>

          {/* <Input 
            placeholder="Click on Get OTP button to get otp on email"
            type={"tel"}
            value={otp}
            onChange={(e)=>{
              setOtp(e.target.value)
            }}
            />
            <button type="submit" onClick={getOTP} style={{color: "white", backgroundColor: "#003580"}}>Get OTP</button>
            <button type="submit" onClick={validOtp} style={{color: "white", backgroundColor: "#003580"}}>Validate</button>
           */}
          {/* <Input
            
            type={"file"}
            id="myfile"
            name="myfile"
            value={hotelImage}
            onChange={(e) => {
              setImage(e.target.value);
            } }
            required /> */}

          <Agreement>
            By creating an account, I consent to the processing of my personal
            data in accordance with the <b>PRIVACY POLICY</b> 
            <div>
            <span style={{ color: "red", fontSize:"13px" }}>{nameError}</span>
            <span style={{ color: "red", fontSize:"13px" }}>{error}</span>
            <span style={{ color: "red", fontSize:"13px" }}>{passwordError}</span>

            </div>
          </Agreement>
          <Button  onClick={handleRegister}>REGISTER</Button>
        </Form>
      </Wrapper>
    </Container>
    <MailList/>
    <Footer/></>
  );
};

export default ManagerRegister;
