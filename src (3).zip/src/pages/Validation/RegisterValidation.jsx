import styled from "styled-components";

import React, { Component, useEffect, useReducer, useState } from 'react';

import Navbar from "../../components/navbar/Navbar";
import Footer from "../../components/footer/Footer";
import MailList from "../../components/mailList/MailList";
import { useNavigate } from "react-router-dom";
import { display } from "@mui/system";
//import "./register.css";



const Container = styled.div`
  width: 100vw;
  height: 120vh;
  background: linear-gradient(
      rgba(255, 255, 255, 0.5),
      rgba(255, 255, 255, 0.5)
    ),
    url("https://images.pexels.com/photos/6984661/pexels-photo-6984661.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940")
      center;
  background-size: cover;
  display: flex;
  align-items: center;
  background-image: url("https://www.vobss.com/wp-content/uploads/2022/07/aesthetic-beach-wallpaper-vobss.jpg");
  justify-content: center;
  
`;

const Wrapper = styled.div`
  width: 40%;
  padding: 20px;
  background-color: white;
  border-radius: 20px;
 
  
 
`;

const Title = styled.h1`
  font-size: 24px;
  font-weight: 300;
`;

const Form = styled.form`
  display: flex;
  flex-direction: column;
`;

const Input = styled.input`
  flex: 1;
  min-width: 40%; 
  margin: 10px 20px 0px 0px;
  padding: 10px;
`;

const Agreement = styled.span`
  font-size: 12px;
  margin: 20px 0px;
`;

const Button = styled.button`
  width: 99%;
  border: none;
  padding: 15px 20px;
  background-color: #003580;
  color: white;
  cursor: pointer;
`;

const Register = () => {
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [mobileNumber, setMobileNumber] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [profession, setProfession] = useState("");
  const [address, setAddress] = useState("");
  const [otp, setOtp] = useState("");


  const [nameError, setNameError] = useState("");
  const [ageError, setAgeError] = useState("");
  const [mobNumError, setMobNumError] = useState("");
  const [passwordError, setPasswordError] = useState("");



  const validName = (e) => {
    let namePattern = /^[a-zA-Z ]+$/;
    
    if(e.target.value==="" || namePattern.test(e.target.value)){
      setName(e.target.value)
      setNameError("")
    }
    else{
      setNameError("Please enter a valid name")
    }
  } 


  const validAge = (e) => {
    let agePattern = /^\d+$/;

    if(e.target.value==="" || agePattern.test(e.target.value)){
      setAge(e.target.value)
      setAgeError("")
    }
    else{
      setAgeError("Please enter value age in number")
    }
  }

  const validMobNum=(e) => {
    let mobNumPattern = /^\d+$/;

    if(e.target.value==="" || mobNumPattern.test(e.target.value)){
      setMobileNumber(e.target.value)
      setMobNumError("")
    }
    else{
      setMobNumError("Please enter a valid number")
    }
  }


  const validPassword = (e) => {

    let passwordPattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,20}$/;
    setPassword(e.target.value);
    if (!passwordPattern.test(e.target.value)) {
      console.log("please enter strong password");
      setPasswordError("please enter strong password(A-Z, a-z,@#!$.,1234..)");
    } else {
      console.log("success");
      setPasswordError("");
    }
  }


  let navigate=useNavigate();
  const handleClick1 = (event) => {
    event.preventDefault()
    const client = { email }
    console.log(client);
    let api="http://localhost:8080/getOtp/"+ email;
    fetch(api, {
      method: "GET",
      //headers: { "Content-Type": "application/json" },
      // body: JSON.stringify(client)
    }).then(res => res.text())
      .then((result) => {
         alert(result);
      });
    };
    const handleClick2 = (event) => {
      event.preventDefault()
      const client = {otp}
      console.log(client);
      let api="http://localhost:8080/validateOtp/"+otp;
      fetch(api, {
        method: "GET",
        // headers: { "Content-Type": "application/json" },
        // body: JSON.stringify(client)
      }).then(res => res.text())
        .then((result) => {
          if(result==="Otp is correct"){
            const client = { name, age, mobileNumber, email, password, profession, address }
            console.log(client);
            fetch("http://localhost:8080/register", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(client)
            }).then(res => res.text())
              .then((result) => {
                alert(result);
                navigate("/managerDashboard");
              });
          }
          if(result==="otp is incorrect"){
            alert(result);
          }
        });
    };
    
  return (
    <><Navbar /><Container>
      <Wrapper>

        <Title>CREATE AN ACCOUNT</Title>
        <Form>
          <Input placeholder="enter full name" id="name" name="name"
            value={name} onChange={validName}
            type={"text"} required />
            <span style={{color:"red", display: "inline-block"}}>{nameError}</span>

          <Input placeholder="enter age" type={"tel"} id="age" name="age"
            value={age} onChange={validAge}
            required />
            <span style={{color:"red"}}>{ageError}</span>
          <Input placeholder="enter mobile number" id="mobileNumber" name="mobileNumber"
            value={mobileNumber} onChange={validMobNum}
            type={"tel"} required />
            <span style={{color:"red"}}>{mobNumError}</span>
          <Input placeholder=" enter email id" id="email" name="email"
            value={email} onChange={(e) => {
              setEmail(e.target.value)
            }}
            type={"email"} required />
          <Input placeholder="enter profession" id="profession" name="profession"
            value={profession} onChange={(event) => {
              setProfession(event.target.value)
            }}
            required />
          <Input placeholder="enter password" id="password" name="password"
            value={password} onChange={validPassword}
            type={"password"} required />
            <span style={{color:"red"}}>{passwordError}</span>
          <Input placeholder="Address" id="address" name="address"
            value={address} onChange={(event) => {
              setAddress(event.target.value)
            }}
            type={"text"} required />
          <Input placeholder="otp" id="otp" name="otp"
            value={otp} onChange={(event) => {
              setOtp(event.target.value)
            }} type={"text"} required />
          <Agreement>
            By creating an account, I consent to the processing of my personal
            data in accordance with the <b>PRIVACY POLICY</b>
          </Agreement>
          <Button onClick={handleClick1}>Get OTP</Button>
          <Button onClick={handleClick2}>Validate and Create User</Button>
        </Form>
      </Wrapper>
    </Container>
      <MailList />
      <Footer /></>
  );
};

export default Register;
