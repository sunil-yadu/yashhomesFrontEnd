
import React from "react";
import styled from "styled-components";
import { useState } from "react";
import { Navbar } from "react-bootstrap";
import Footer from "../../components/footer/Footer";
import MailList from "../../components/mailList/MailList";
//import "./hotelRegistration.css"

const Container = styled.div`
  width: 100vw;
  height: 130vh;
  background: linear-gradient(
      rgba(255, 255, 255, 0.5),
      rgba(255, 255, 255, 0.5)
    ),
    url("https://images.pexels.com/photos/6984661/pexels-photo-6984661.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940")
      center;
  background-size: cover;
  display: flex;
  align-items: center;
  background-image: url("https://www.vobss.com/wp-content/uploads/2022/07/aesthetic-beach-wallpaper-vobss.jpg");
  justify-content: center;
  
`;

const Wrapper = styled.div`
  width: 45%;
  padding: 20px;
  background-color: white;
  border-radius: 20px;
 
`;

const Title = styled.h1`
  font-size: 24px;
  font-weight: 300;
  text-align: center;
`;

const Form = styled.form`
  display: inline;
  flex-direction: column;
`;

const Input = styled.input`
  flex: 1;
  min-width: 40%;
  margin: 10px 10px 0px 0px;
  padding: 10px;
  width: 550px
`;

const Agreement = styled.span`
  font-size: 12px;
  margin: 20px 0px;
`;

const Button = styled.button`
  width: 100%;
  border: none;
  padding: 15px 20px;
  background-color: #003580;
  color: white;
  cursor: pointer;
  margin-top: 20px
  `;


const HotelRegister = () => {

    const [registrationNumber, setRegistrationNumber] = useState("");
    const [hotelName, setHotelName] = useState("");
    const [totalRooms, setTotalRooms] = useState("");
    const [availableAcRooms, setAvailableAcRooms] = useState("");
    const [availableNonAcRooms, setAvailableNonAcRooms] = useState("");
    const [address, setAddress] = useState("");
    const [charges, setCharges] = useState("");
    const [foodIncluded, setFoodIncluded] = useState("");
    const [isBar, setIsBar] = useState("");
    const [imageUrl, setImageUrl] = useState("")


    const [regNumError,setRegNumError] = useState("");
    const [totalRoomsError, setTotalRoomsError] = useState("");

    const [totalAcRoomError, setTotalAcRoomError] = useState("");
    const [totalNonAcRoomError, setTotalNonAcRoomError] = useState("");
    const [chargesError, setChargesError] = useState("");
    const [addressError, setAddressError] = useState("");



    const handleClick = (event) => {

        alert("check");
        event.preventDefault()
        const hotel = {registrationNumber,hotelName,totalRooms,availableAcRooms,availableNonAcRooms,address,charges,foodIncluded,isBar}
        console.log(hotel);
        fetch("http://localhost:8080/saveHotelInformation", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(hotel)
    
        }).then(() => {
          console.log("New User added")
        })
    
      }


      const submitHandler = (e) => {
        e.preventDefault()
        console.log("submitted");
      }


    const validRegistrationNumber=(e)=>{
        let regNumPattern = /^[A-Za-z0-9]*$/;
        
        if (regNumPattern.test(e.target.value)) {
            setRegistrationNumber(e.target.value);
            setRegNumError("")
        }
           else {
            console.log("please enter a valid Registration Number");
            setRegNumError("Please enter a valid Registration Number");
          }
    }

    const validTotalRooms = (e) => {
        let roomsPattern = /^\d+$/;

        if (e.target.value === "" || roomsPattern.test(e.target.value)) {
                setTotalRooms(e.target.value);
                setTotalRoomsError("")
        }
        else{
            console.log("please enter a no.");
            setTotalRoomsError("please enter a number");
        }

    }


  const validTotalAcRoom = (e) => {

    
    let totalAcRoomPattern = /^\d+$/;

        if (e.target.value === "" || totalAcRoomPattern.test(e.target.value)) {
                setAvailableAcRooms(e.target.value);
                setTotalAcRoomError("")
        } else {
          console.log("please enter a valid total Available Ac Room");
          setTotalAcRoomError("Please enter valid total Available Ac rooms");
        }

  };

  const validTotalNonAcRoom = (e) => {
    let totalNonAcroomPattern =  /^\d+$/;
    if (e.target.value === "" || totalNonAcroomPattern.test(e.target.value)) {
       setAvailableNonAcRooms(e.target.value);
       setTotalNonAcRoomError("")
    } else {
      console.log("please enter a valid total Available Non Ac Room");
      setTotalNonAcRoomError("Please enter valid total Available Non Ac rooms");
    }
  };

  const validCharges = (e) => {
    let chargesPattern = /^\d+$/;
    if (e.target.value === "" || chargesPattern.test(e.target.value)) {
       setCharges(e.target.value);
       setChargesError("")
    } else {
      console.log("please enter a valid Charges");
      setChargesError("Please enter valid Charges");
    }
  };

  const validAddress = (e) => {
    let addressPattern = /^[A-Za-z0-9]*$/;
    if (e.target.value === "" || addressPattern.test(e.target.value)) {
       setAddress(e.target.value);
       setAddressError("")
    } else {
      console.log("please enter a valid Address");
      setAddressError("Please enter a valid Address");
    }
  };



    



    return (

    <div>
        <Navbar/>
        <Container>
        <Wrapper>
        <Title>Hotel Information Form</Title>
      <Form
       onSubmit={submitHandler}
    >
      <div>
          <Input type={"text"} maxLength={5} value={registrationNumber} onChange={validRegistrationNumber} placeholder="Enter hotel registration number" required/>
          <span style={{color:"red"}}>{regNumError}</span>
        </div>

        <div>
          <Input type={"text"} value={hotelName} onChange={(e)=>{
            setHotelName(e.target.value)
          }}
            placeholder="Enter hotel name" required/>
        </div>
        <div>
          <Input type={"tel"} value={totalRooms} onChange={validTotalRooms} placeholder="Enter Total Rooms" required/>
          <span style={{color:"red"}}>{totalRoomsError}</span>
        </div>
       
        <div>
          <Input type={"tel"} value={availableAcRooms} onChange={validTotalAcRoom} placeholder="Total Available Ac Rooms" required/>
          <span style={{color:"red"}}>{totalAcRoomError}</span>
        </div>
        <div>
          <Input type={"tel"} value={availableNonAcRooms} onChange={validTotalNonAcRoom} placeholder="Total Available NonAc Rooms" required/>
          <span style={{color:"red"}}>{totalNonAcRoomError}</span>
        </div>
        <div>
          <Input type={"text"} value={address} onChange={validAddress} placeholder="Enter Your Address" required/>
          <span style={{color:"red"}}>{addressError}</span>
        </div>
        <div>
          <Input type={"tel"} value={charges} onChange={validCharges} placeholder="Enter Charges" required/>

<span style={{color:"red"}}>{chargesError}</span>
        </div>
        <div>
          <Input type={"text"} value={foodIncluded} onChange={(e) => {
              setFoodIncluded(e.target.value);
            }} placeholder="Food Included or not(Yes/No)" required/>
        </div>
        <div>
          <Input type={"text"} value={isBar} onChange={(e) => {
              setIsBar(e.target.value);
            }} placeholder="Bar Availabiliy(Yes/No)" required/>
           
        </div>
        <div>
            <Input type={"url"} value={imageUrl} onChange={(e)=>{
                setImageUrl(e.target.value)
            }} placeholder="Enter image url "/>
        </div>
        <div>
            
            <Button onClick={handleClick} >REGISTER</Button>

        </div>
         </Form>
     
     </Wrapper>
    </Container>
        <MailList/>
        <Footer/>
    </div>
  );
}

export default HotelRegister;