import "./navbar.css"
import { faPerson, faTreeCity } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { getData, setData } from "../../SessionMaintain";
//import logo1 from "./logo.jpg";
const Navbar = () => {
  const [value, setValue] = useState("");
  const navigate = useNavigate();
  return (
    <div className="navbar">
      <div className="navContainer">
        <span className="logo"><FontAwesomeIcon icon={faTreeCity} /> Yash Hotels</span>
        <div className="navItems">
          <button className="navButton" onClick={() => {
            navigate("/managerLogin");
          }}> <FontAwesomeIcon icon={faPerson} /> List your property</button>
          <button className="navButton" onClick={() => {
            navigate("/userlogin");
          }}> <FontAwesomeIcon icon={faPerson} /> Register/Sign in</button>
          <button className="navButton" onClick={() => {
            navigate("/adminLogin");
          }}> <FontAwesomeIcon icon={faPerson} /> Admin Login </button>
          <button className="navButton" onClick={() => {
            setData("null")
            navigate("/");
           }}>Logout</button>

        </div>
      </div>
    </div>
  )
}


export default Navbar