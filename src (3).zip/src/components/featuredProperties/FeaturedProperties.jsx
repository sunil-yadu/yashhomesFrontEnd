import "./featuredProperties.css";

const FeaturedProperties = () => {
  return (
    <div className="fp">
      <div className="fpItem">
        <img
          src="	https://www.indovacations.net/hotels/images1/HotelGoldRegency3.jpg"
          alt=""
          className="fpImg"
        />
        <span className="fpName">Hotel Gold Regency</span>
        <span className="fpCity">Paharganj, Delhi</span>
        <span className="fpPrice">Starting from Rs. 2979/- per night</span>
        <div className="fpRating">
          <button>8.9</button>
          <span>Excellent</span>
        </div>
      </div>
      <div className="fpItem">
        <img
          src="https://lh3.googleusercontent.com/p/AF1QipPMbSTrbNYLcsF572pr8E8SViXeHdyibA3WrAur=w592-h404-n-k-rw-no-v1"
          alt=""
          className="fpImg"
        />
        <span className="fpName">Ashiana Clarks Inn, Shimla</span>
        <span className="fpCity">Shimla</span>
        <span className="fpPrice">Starting from Rs. 4686/- per night</span>
        <div className="fpRating">
          <button>8.5</button>
          <span>Excellent</span>
        </div>
      </div>
      <div className="fpItem">
        <img
          src=" https://lh3.googleusercontent.com/proxy/_uHC6Om0qzBuEV0UWxANWPLCEnVf2v-vDA54xU1QpcXwZC5S_EhN1qrOTWuNQepAQ0foh-eH4RkEgg3ppo8FVdsrIGrTKUICYxxUhXw_-LrM8jgyeUCGDLZvnAZHeStKReaqmdgEJXRAUa8z7ICiaol35-bhosk=w592-h404-n-k-rw-no-v1"
          alt=""
          className="fpImg"
        />
        <span className="fpName">DoubleTree by Hilton Hotel Goa - Arpora - Baga</span>
        <span className="fpCity">Goa</span>
        <span className="fpPrice">Starting from Rs. 4703/- per night</span>
        <div className="fpRating">
          <button>8.0</button>
          <span>Excellent</span>
        </div>
      </div>
      <div className="fpItem">
        <img
          src="	https://images.trvl-media.com/hotels/1000000/580000/577900/577808/36c6628f_z.jpg"
          alt=""
          className="fpImg"
        />
        <span className="fpName">ITC Maratha Mumbai</span>
        <span className="fpCity">Andheri Mumbai</span>
        <span className="fpPrice">Starting from Rs. 10000/- per night</span>
        <div className="fpRating">
          <button>8.9</button>
          <span>Excellent</span>
        </div>
      </div>
    </div>
  );
};

export default FeaturedProperties;
