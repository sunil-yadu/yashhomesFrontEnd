
export function setData(data)
{
    sessionStorage.setItem("LoggedIn",data)
}
export function getData()
{
    return sessionStorage.getItem("LoggedIn");
}